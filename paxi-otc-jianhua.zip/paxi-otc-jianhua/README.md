# Paxi OTC DApp

Paxi Network 上的去中心化场外交易 (OTC) 平台。支持 PAXI、USDC、USDT、ETH、BNB、SOL、BTC 等
Paxi 链上 IBC 包装资产的任意两两兑换。

## 项目结构

```
paxi-otc-jianhua/
├── index.html          # 前端 DApp 入口
├── app.js              # 前端核心逻辑
├── shared.js           # 网络配置、交易构建、工具函数
├── compat.js           # PaxiCosmJS 兼容层（protobuf 编码器）
├── contract/           # Rust 智能合约
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── msg.rs       # 消息定义
│       ├── state.rs     # 状态存储
│       └── contract.rs  # 核心逻辑
└── README.md
```

## 支持的代币

PaxiHub 钱包已经打通了 **Paxi、BNB、ETH、Solana、Bitcoin** 的跨链通道。在这些通道中，
用户将 BNB/ETH/SOL/BTC/USDC/USDT 从各自原链桥接到 Paxi 链后，它们会以 Paxi 链上
**原生 denom**（常见形式为 `ibc/XXXXXXXXXXXXXXXXXXXX...` 或 Paxi 官方分配的包装名）
的身份存在。

CosmWasm OTC 合约使用 Cosmos SDK `bank` 模块（`info.funds` + `BankMsg::Send`）处理资金，
天然支持 **Paxi 链上任何原生 denom**，包括：

| 代币 | 常见展示名 | 精度（decimals） | 原链 |
|------|-----------|-----------------|------|
| PAXI  | `upaxi` | 6 | Paxi |
| USDC | 通常是 IBC 包装 | 6 | (原链各异) |
| USDT | 通常是 IBC 包装 | 6 | (原链各异) |
| ETH  | 通常是 IBC 包装 | 18 | Ethereum |
| BNB  | 通常是 IBC 包装 | 18 | BNB Chain |
| SOL  | 通常是 IBC 包装 | 9  | Solana |
| BTC  | 通常是 IBC 包装 | 8  | Bitcoin |

> 💡 **用户端不用关心 denom**：连接钱包后，前端会从 `/cosmos/bank/v1beta1/balances/<地址>`
> 自动加载你钱包里**所有**代币余额，挂单时下拉框会显示这些 denom 的真实名称和余额。
> 你只需要在界面中选"ETH""BTC"等展示名即可，前端会自动转换成真实链上 denom。

### 跨链 OTC 兑换示例

如果你在 PaxiHub 里把 1 ETH 从 Ethereum 跨链到 Paxi 钱包：

1. 你会在 Paxi 钱包中看到 **余额为 1 ETH**（在 Paxi 链上以 `ibc/XXXX` denom 形式）
2. 你可以在 OTC DApp 中挂单：**卖出 1 ETH → 买入 3,000 USDC**
3. 买家支付 3,000 USDC（Paxi 链上 IBC 包装的 USDC），合约自动交割
4. 你拿到 3,000 USDC，买家拿到 1 ETH，全程都在 Paxi 链上结算
5. 如果需要把 ETH / USDC 转回原链，可通过 PaxiHub 的「转账-跨链通道」操作

## 功能

- **市场浏览**：查看所有活跃挂单，显示单价和剩余时间；支持按「卖出币种/买入币种」筛选
- **创建挂单**：卖家存入代币到智能合约托管，可一键填入最大余额，内置常见代币
- **购买（吃单）**：买家支付对应代币，合约自动交割，支持找零、误发代币原路退回
- **取消挂单**：卖家随时取消，代币立即退回
- **超时退款**：挂单超时后，卖家可取回代币
- **合约部署**：支持从 DApp 内直接通过 Code ID 实例化合约
- **钱包余额面板**：连接钱包后自动展示所有链上余额（PAXI/USDC/USDT/ETH/BNB/SOL/BTC...）

## 快速开始

### 1. 本地运行前端

由于 PaxiHub 钱包需要通过 HTTP 访问页面（不能直接打开 file://），需要启动一个本地服务器：

```bash
# Python 3
python -m http.server 8080

# 或 Python 2
python -m SimpleHTTPServer 8080
```

然后浏览器访问 `http://localhost:8080`

### 2. 部署智能合约

#### 2.1 安装 Rust 工具链

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
rustup target add wasm32-unknown-unknown
```

#### 2.2 编译合约

```bash
cd contract
cargo wasm
```

编译产物在 `target/wasm32-unknown-unknown/release/paxi_otc.wasm`

#### 2.3 优化合约体积

```bash
docker run --rm -v "$(pwd)":/code \
  --mount type=volume,source="$(basename "$(pwd)")_cache",target=/code/target \
  --mount type=volume,source=registry_cache,target=/usr/local/cargo/registry \
  cosmwasm/workspace-optimizer:0.15.1
```

优化后的文件在 `artifacts/paxi_otc.wasm`

#### 2.4 上传合约

```bash
paxid tx wasm store ./artifacts/paxi_otc.wasm \
  --from <钱包名称> \
  --gas 5000000 \
  --chain-id paxi-mainnet \
  --node https://mainnet-rpc.paxinet.io
```

记下返回的 **Code ID**。

#### 2.5 实例化合约

**方式 A：在 DApp 中实例化（推荐）**

1. 打开 DApp，连接钱包
2. 进入「合约设置」页面
3. 输入 Code ID，点击「实例化合约」
4. 实例化成功后，合约地址会自动保存

**方式 B：命令行实例化**

```bash
paxid tx wasm instantiate <CodeID> '{}' \
  --from <钱包名称> \
  --label "Paxi OTC Market" \
  --gas 500000 \
  --chain-id paxi-mainnet \
  --node https://mainnet-rpc.paxinet.io
```

实例化后得到的合约地址就是你的 OTC 市场地址。

### 3. 使用 DApp

1. 在「合约设置」页面输入合约地址（或通过 Code ID 实例化后自动填入）
2. 连接 PaxiHub 钱包
3. **创建挂单**：选择卖出代币和数量，设定买入代币和数量，确认交易
4. **购买**：在「市场浏览」中找到感兴趣的挂单，点击「购买」
5. **管理订单**：在「我的订单」中取消或退款

## 合约接口

### 执行消息 (ExecuteMsg)

| 操作 | 消息 | 附带资金 | 说明 |
|------|------|----------|------|
| 创建挂单 | `{ "create_order": { "ask_denom": "uusdc", "ask_amount": "1000000", "timeout": 604800 } }` | offer 代币 | 卖家存入代币 |
| 购买 | `{ "execute_order": { "id": 1 } }` | ask 代币 | 买家付款，自动交割 |
| 取消 | `{ "cancel_order": { "id": 1 } }` | 无 | 仅卖家可取消 |
| 退款 | `{ "refund_order": { "id": 1 } }` | 无 | 仅超时后卖家可退款 |

### 查询消息 (QueryMsg)

| 查询 | 消息 | 返回 |
|------|------|------|
| 查询单个订单 | `{ "get_order": { "id": 1 } }` | Order |
| 列出所有订单 | `{ "list_orders": { "limit": 50 } }` | Vec\<Order\> |
| 列出活跃订单 | `{ "list_active_orders": { "limit": 100 } }` | Vec\<Order\> |
| 查询卖家订单 | `{ "list_orders_by_seller": { "seller": "paxi1..." } }` | Vec\<Order\> |
| 订单总数 | `{ "get_order_count": {} }` | u64 |

## 安全特性

- 所有交易由智能合约托管，无需信任第三方
- 买家多付的代币会自动找零退回
- 买家误发的其他代币会原路退回
- 卖家可随时取消活跃挂单，代币立即退回
- 挂单超时后，卖家可发起退款取回代币
- 订单 ID 自增，不可篡改

## 技术栈

- **智能合约**：Rust + CosmWasm 1.5.0
- **前端**：原生 HTML/JS/CSS（无构建步骤）
- **钱包**：PaxiHub
- **SDK**：PaxiCosmJS + 自定义 protobuf 兼容层
- **网络**：Paxi 主网 / 测试网
